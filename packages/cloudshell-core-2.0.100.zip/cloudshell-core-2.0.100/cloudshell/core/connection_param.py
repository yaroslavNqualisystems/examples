class ConnectionParam(object):
    def __init__(self):
        self.type = ''
        self.vlanIds = []
        self.mode = ''
