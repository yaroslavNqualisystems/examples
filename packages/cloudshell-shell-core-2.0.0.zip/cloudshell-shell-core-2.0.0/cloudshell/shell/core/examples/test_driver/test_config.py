# from cloudshell.shell.core import driver_config as config
from cloudshell.shell.core.examples.test_driver.test_handler import TestHandler



HANDLER_CLASS = TestHandler


# GG="dsd"
# ERROR_LIST = ['dsd', 'dddddd']