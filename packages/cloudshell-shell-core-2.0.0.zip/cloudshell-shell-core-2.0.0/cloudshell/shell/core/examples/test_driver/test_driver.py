from cloudshell.shell.core.context.context_utils import context_from_args
from cloudshell.shell.core.driver_bootstrap import DriverBootstrap
import inject
import test_config as config


class TestDriver:
    def __init__(self):
        bootstrap = DriverBootstrap()
        # bootstrap.add_config(config)
        bootstrap.initialize()
        # self.config = inject.instance('config')

    @context_from_args
    def initialize(self, context):
        """
        :type context: cloudshell.shell.core.context.driver_context.InitCommandContext
        """
        return 'Finished initializing'

    # Destroy the driver session, this function is called everytime a driver instance is destroyed
    # This is a good place to close any open sessions, finish writing to log files
    def cleanup(self):
        pass

    @context_from_args
    @inject.params(logger='logger', context='context', cli='cli_service')
    def simple_command(self, context, command, logger=None, cli=None):
        logger.info('Send command')
        return cli.send_command(command)
