from cloudshell.shell.core.examples.test_driver.test_test_test import create_obj
# from cloudshell.shell.core.examples.test_driver.test_test_test import TestFF



class TestFF:
    pass


# tt = TestFF()

if __name__ == '__main__':

    if isinstance(create_obj(), TestFF):
        print('Yes')



