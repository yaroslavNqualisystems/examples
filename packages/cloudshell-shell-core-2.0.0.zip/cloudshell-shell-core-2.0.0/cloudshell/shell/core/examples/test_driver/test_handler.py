import inject


class TestHandler:
    @inject.params(cli='cli_service')
    def send_dd(self, cli=None):
        out = cli.send_config_command('ls')
        return out
