class DriverResponseRoot(object):
    def __init__(self):
        self.driverResponse = None