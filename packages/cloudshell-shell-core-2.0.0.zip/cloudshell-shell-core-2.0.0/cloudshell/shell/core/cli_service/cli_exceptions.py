class CommandExecutionException(Exception):
    pass
